// 页面通过同源接口与本地后端通信；所有返回内容以文本插入，避免将用户内容解释为 HTML。
const form = document.querySelector('#diagnose-form');
const symptom = document.querySelector('#symptom');
const count = document.querySelector('#count');
const submit = document.querySelector('#submit');
const content = document.querySelector('#result-content');
const resultStatus = document.querySelector('#result-status');
const caseList = document.querySelector('#case-list');
const connection = document.querySelector('#connection');

function updateCount() { count.textContent = symptom.value.length; }
symptom.addEventListener('input', updateCount);

async function api(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || '服务暂时不可用，请稍后重试。');
  return data;
}
function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}
function resultBlock(title, value, listType) {
  const block = element('section', undefined, 'result-block');
  block.append(element('h3', title));
  if (listType) {
    const list = element(listType);
    (Array.isArray(value) ? value : []).forEach(item => list.append(element('li', item)));
    if (!list.children.length) list.append(element('li', '暂无可用信息'));
    block.append(list);
  } else block.append(element('p', value || '暂无可用信息'));
  return block;
}
function renderResult(data) {
  content.replaceChildren();
  content.append(resultBlock('初步方向 / ' + (data.category || '待确认'), data.summary));
  content.append(resultBlock('调查线索', data.evidence, 'ul'));
  content.append(resultBlock('建议排查步骤', data.steps, 'ol'));
  content.append(element('p', data.disclaimer || '本结果仅供参考，请结合实际情况核验。', 'disclaimer'));
  resultStatus.textContent = '已生成 · 待核验';
}
form.addEventListener('submit', async event => {
  event.preventDefault();
  const value = symptom.value.trim();
  if (!value) { symptom.setCustomValidity('请描述网络问题'); symptom.reportValidity(); symptom.setCustomValidity(''); return; }
  submit.disabled = true; submit.firstElementChild.textContent = '正在整理线索…'; resultStatus.textContent = '调查中';
  try {
    const data = await api('/api/diagnose', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({symptom:value})});
    renderResult(data);
    document.querySelector('#result').scrollIntoView({behavior:'smooth', block:'nearest'});
  } catch (error) {
    content.replaceChildren(element('p', error.message || '连接失败，请确认本地服务已启动。', 'error'));
    resultStatus.textContent = '未完成';
  } finally { submit.disabled = false; submit.firstElementChild.textContent = '生成调查建议'; }
});
async function loadCases() {
  try {
    const data = await api('/api/cases');
    caseList.replaceChildren();
    (data.cases || []).forEach((item, index) => {
      const button = element('button', undefined, 'case'); button.type = 'button';
      const number = element('span', String(index + 1).padStart(2, '0') + ' / EXAMPLE', 'case-number');
      const arrow = element('span', '↗', 'case-arrow'); number.append(arrow);
      button.append(number, element('strong', item.title), element('p', item.description));
      button.addEventListener('click', () => { symptom.value = item.symptom || ''; updateCount(); symptom.focus(); document.querySelector('#investigate').scrollIntoView({behavior:'smooth'}); });
      caseList.append(button);
    });
    if (!caseList.children.length) caseList.append(element('p', '暂无示例场景。', 'subtle'));
  } catch { caseList.replaceChildren(element('p', '无法加载示例，请确认本地服务已启动。', 'subtle')); }
}
async function checkHealth() {
  try { const data = await api('/api/health'); connection.textContent = data.mode || '本地服务已连接'; }
  catch { connection.textContent = '服务未连接'; document.querySelector('.status-dot').classList.add('offline'); }
}
loadCases(); checkHealth();
