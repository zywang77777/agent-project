"""校园网络调查助手：静态页面与本地规则演示接口。

在 VS Code 中直接运行此文件，再访问 http://127.0.0.1:8000/。
"""

import json
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

# 可调运行参数：仅监听本机，不需要安装第三方依赖。
HOST = "127.0.0.1"
PORT = 8000
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
MAX_BODY_BYTES = 65536

# 以下为人工编写的演示案例，不是实际网络测量数据。
CASES = [
    {"id": "congestion", "title": "晚高峰链路拥塞", "symptom": "宿舍晚高峰视频卡顿，链路利用率较高", "description": "演示线索：从时段与链路负载入手调查。"},
    {"id": "device", "title": "设备故障", "symptom": "宿舍网络卡顿，交换机端口出现错误和丢包", "description": "演示线索：检查设备状态与端口错误。"},
    {"id": "wifi", "title": "Wi-Fi 干扰", "symptom": "宿舍 Wi-Fi 信号不稳定，无线干扰明显", "description": "演示线索：比较无线和有线连接。"},
    {"id": "route", "title": "路径变化", "symptom": "访问校外服务时延突然升高，网络路由发生变化", "description": "演示线索：核对路径和时延变化。"},
]

RULES = [
    ("可能存在设备异常", ("交换机", "端口", "设备故障", "错误包"),
     "描述涉及设备或端口异常，需要核验设备状态后才能确定原因。",
     ["检查涉及端口的错误计数、丢包与设备日志。", "比较其他端口和设备，排除单终端问题。", "记录变化时间并联系网络运维人员检查设备。"]),
    ("可能存在路径变化", ("路由", "路径", "跳数"),
     "描述涉及网络路径，需比较故障前后的路径与时延。",
     ["记录目的地址及路径变化的时间。", "比较不同目的地和不同时间的路径与时延。", "联系网络运维人员核对路由变更和链路状态。"]),
    ("可能存在链路拥塞", ("拥塞", "高峰", "利用率", "带宽占满"),
     "描述涉及流量高峰或链路负载，需结合利用率和丢包记录核验。",
     ["核对高峰和非高峰的链路利用率、时延与丢包。", "对比同一链路不同用户和其他时段，排除单设备问题。", "由网络运维人员评估流量优化或扩容。"]),
    ("认证问题", ("认证", "登录", "登陆", "账号", "密码", "portal"),
     "描述涉及校园网认证，建议先核对登录流程。",
     ["检查账号和密码是否正确，并确认账号状态。", "断开重连校园网，打开学校提供的认证页面。", "若仍失败，记录提示文字和时间，联系学校网络服务部门。"]),
    ("名称解析问题", ("dns", "解析", "域名", "部分网站", "网站打不开"),
     "描述涉及网站访问或名称解析，可先比较不同网站的访问情况。",
     ["尝试访问多个常用网站，确认问题是否只发生在单个网站。", "检查设备是否已连接到正确的网络，并重新连接。", "记录错误提示，联系学校网络服务部门核实 DNS 状态。"]),
    ("无线连接问题", ("断线", "掉线", "信号", "wifi", "wi-fi", "无线", "连不上"),
     "描述涉及无线连接，建议调查信号覆盖与干扰。",
     ["比较同地点有线与无线连接的时延和丢包。", "检查无线信道、信号强度和干扰情况。", "记录地点、时间和设备型号，向学校网络服务部门反馈。"]),
    ("网络速度问题", ("慢", "卡顿", "卡", "延迟", "速度", "丢包"),
     "描述涉及网络速度或延迟，建议对比设备和时段。",
     ["比较不同时间段、不同网站和设备的表现。", "检查是否有大文件下载或其他占用带宽的任务。", "记录发生时间和地点，必要时联系学校网络服务部门。"]),
]

# 仅与完全一致的演示案例绑定；这些数字是手工构造的示例，不是测量结果。
DEMO_METRICS = {
    "congestion": {"baseline_rtt_ms": 20, "current_rtt_ms": 85, "baseline_load_pct": 35, "current_load_pct": 88},
    "device": {"baseline_rtt_ms": 18, "current_rtt_ms": 70, "baseline_load_pct": 30, "current_load_pct": 32},
    "wifi": {"baseline_rtt_ms": 16, "current_rtt_ms": 62, "baseline_load_pct": 28, "current_load_pct": 29},
    "route": {"baseline_rtt_ms": 25, "current_rtt_ms": 90, "baseline_load_pct": 30, "current_load_pct": 33},
}
DEMO_PATHS = {
    "congestion": (["宿舍", "汇聚", "出口"], ["宿舍", "汇聚", "出口"]),
    "device": (["宿舍", "汇聚", "出口"], ["宿舍", "汇聚", "出口"]),
    "wifi": (["宿舍", "汇聚", "出口"], ["宿舍", "汇聚", "出口"]),
    "route": (["宿舍", "汇聚A", "出口"], ["宿舍", "汇聚B", "出口"]),
}


def compare_metrics(values):
    """对模拟基线和异常值进行差值计算。"""
    delta_rtt = values["current_rtt_ms"] - values["baseline_rtt_ms"]
    delta_load = values["current_load_pct"] - values["baseline_load_pct"]
    return (f"模拟检查：RTT 从 {values['baseline_rtt_ms']} ms 到 {values['current_rtt_ms']} ms，"
            f"变化 {delta_rtt:+d} ms；负载从 {values['baseline_load_pct']}% 到 "
            f"{values['current_load_pct']}%，变化 {delta_load:+d} 个百分点。")


def compare_paths(paths):
    """比较模拟路径节点列表是否一致。"""
    baseline, current = paths
    outcome = "一致" if baseline == current else "不同"
    return f"模拟检查：基线路径 {' → '.join(baseline)}；当前路径 {' → '.join(current)}；两者{outcome}。"


def demo_evidence(symptom):
    """只有选择原样示例时才展示对应模拟数据，避免与真实描述混淆。"""
    case = next ( (item for item in CASES if item["symptom"] == symptom), None)
    if case is None:
        return []
    case_id = case["id"]
    return ["以下数字和路径是该演示案例预设的模拟数据，非网络实测。",
            compare_metrics(DEMO_METRICS[case_id]), compare_paths(DEMO_PATHS[case_id])]


def diagnose(symptom):
    """根据关键词给出排查建议；这不是网络实测或大模型判断。"""
    text = symptom.casefold()
    for category, keywords, summary, steps in RULES:
        matches = [word for word in keywords if word.casefold() in text]
        if matches:
            return {"category": category, "summary": summary,
                    "evidence": [f"用户描述中包含：{'、'.join(matches)}；尚未核验。"] + demo_evidence(symptom) + ["当前没有真实测量数据，缺少支持或反证，不能确定根因。"], "steps": steps,
                    "disclaimer": "本结果由本地关键词规则生成，仅供排查参考，未连接真实校园网络或大模型。"}
    return {"category": "待进一步调查", "summary": "现有描述不足以匹配演示规则，请补充现象。",
            "evidence": ["未匹配到当前演示规则中的关键词。"],
            "steps": ["补充发生地点、时间、设备和具体错误提示。", "对比其他设备或其他网络是否也有相同问题。", "如果问题持续，请联系学校网络服务部门。"],
            "disclaimer": "本结果由本地关键词规则生成，仅供排查参考，未连接真实校园网络或大模型。"}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # 与示例一样由后端同时提供页面和接口，路径不依赖启动目录。
        super().__init__(*args, directory=str(FRONTEND_DIR), **kwargs)

    def send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path in ("/health", "/api/health"):
            self.send_json(200, {"status": "ok", "mode": "本地规则演示"})
        elif path == "/api/cases":
            self.send_json(200, {"cases": CASES})
        elif path.startswith("/api/"):
            self.send_json(404, {"error": "接口不存在"})
        else:
            super().do_GET()

    def do_POST(self):
        if urlsplit(self.path).path != "/api/diagnose":
            self.send_json(404, {"error": "接口不存在"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= MAX_BODY_BYTES:
                raise ValueError("请求内容为空或过长")
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("symptom"), str):
                raise ValueError("请描述网络问题")
            symptom = data["symptom"].strip()
            if not symptom:
                raise ValueError("请描述网络问题")
            if len(symptom) > 2000:
                raise ValueError("问题描述不能超过 2000 字")
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            self.send_json(400, {"error": str(exc) if isinstance(exc, ValueError) else "请求格式错误"})
            return
        self.send_json(200, diagnose(symptom))


def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"校园网络调查助手已启动：http://{HOST}:{PORT}/", flush=True)
    print("按 Ctrl+C 停止服务。", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
